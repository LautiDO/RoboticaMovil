function weight = measurement_model(z, x, l)
    % Computes the observation likelihood of all particles.
    %
    % The employed sensor model is range only.
    %
    % z: set of landmark observations. Each observation contains the id of the landmark observed in z(i).id and the measured range in z(i).range.
    % x: set of current particles
    % l: map of the environment composed of all landmarks
    sigma = [0.2];
    weight = ones(size(x, 1), 1);

    if size(z, 2) == 0
        return
    end
    
    for i = 1:size(z, 2)
        landmark_position = [l(z(i).id).x, l(z(i).id).y];
        measurement_range = [z(i).range];
%--------------------------------------------------------------------------
     % Calcular la distancia esperada desde cada partícula al marcador
        dx = x(:,1) - landmark_position(1);
        dy = x(:,2) - landmark_position(2);
        
        expected_range = sqrt(dx.^2 + dy.^2); % Apartir de las distacias entre el robot y el landmark en x e y , calculo la distancia hasta el landmark
        
        % Calcular el likelihood de esa medición para cada partícula
        p = (1 / (sqrt(2 * pi) * sigma)) * exp(-0.5 * ((measurement_range - expected_range).^2) / sigma^2);
        
        % Actualizar el peso de cada partícula multiplicando (porque las observaciones son independientes)
        weight = weight .* p;
%--------------------------------------------------------------------------
        
    end

    weight = weight ./ size(z, 2);
end
