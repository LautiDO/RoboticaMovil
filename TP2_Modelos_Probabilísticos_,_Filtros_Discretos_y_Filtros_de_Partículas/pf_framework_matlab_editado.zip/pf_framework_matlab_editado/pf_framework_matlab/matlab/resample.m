function new_particles = resample(particles, weights)
    % Returns a new set of particles obtained by performing
    % stochastic universal sampling.
    %
    % particles (M x D): set of M particles to sample from. Each row contains a state hypothesis of dimension D.
    % weights (M x 1): weights of the particles. Each row contains a weight.
    new_particles = [];
    
    M = size(particles, 1);
    
%--------------------------------------------------------------------------
    % Distancia entre pasos
    step = 1 / M;

    % Primer paso aleatorio entre 0 y step
    start = rand * step;
    
    punteros = start + (0:M-1) * step; % M saltos equiespacidos
    
    weights_cumsum = cumsum(weights); % Acumulo todos los pesos
    i=1;
    for j = 1:M
        
        while punteros(j)< weights_cumsum(i) && i < M
            i = i + 1; %Salteo la particula por que el puntero no cayo en el tramo asignado a esa particula
        end
    new_particles(j, :) = particles(i, :);  % Elegimos esa partícula
    end
%--------------------------------------------------------------------------
end
